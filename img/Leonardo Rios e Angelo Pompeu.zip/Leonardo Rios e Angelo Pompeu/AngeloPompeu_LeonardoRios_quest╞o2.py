#As entradas testadas, além dos exemplos, e suas respectivas saídas, são as seguintes:
#1 2 5 2 -> Verdadeira
#3 4 5 3 -> Falsa
#4 2 4 3 -> Verdadeira
#9 8 9 7 -> Verdadeira
#7 5 3 7 -> Falsa

print("Esse programa diz se uma cobra coral é verdadeira ou não baseado em quatro cores do seu padrão.")
print("As quatro cores deverão ser digitadas em forma numérica, onde cada dígito representa uma cor, seguindo um dos seguintes padrões:")
print("X A X B\nA X B X\nX A B X\nOnde X, A e B são digítos distintos.")
print("São permitidos apenas números entre 1 e 9 (inclusivo), e a entrada deve, obrigatóriamente, possuir 4 cores.")
print("Exemplo de entrada:\n3 5 9 3")
print("No fim do programa, será perguntado se o usuário deseja testar uma nova entrada. \n\n")

#Aqui começa o loop de entradas. Enquanto a variável novaEntrada for 1, o programa estará aceitando novas entradas de padrões de cores.
novaEntrada = 1
while novaEntrada == 1:
    
    #Esse loop verifica se o usuário digitou o padrão de cores obedecendo as regras estabelecidas anteriormente.
    #No caso de não obedecer, o programa pede outra entrada.
    entradaErrada = 1
    while entradaErrada == 1:
        variavelControle = 0
        padrao = input("Digite o padrão de cores da cobra. \n")
        letraEncontrada = 0
        
        entradaErrada = 0
        #Nesse bloco, é verificado, nessa ordem:
        #Se há dois dígidos seguidos sem espaço entre eles, o que implica em um número maior que 9.
        #Se um dos dígitos do padrão digitado é 0, o que não é permitido pelo programa.
        #Se há mais do que 7 dígitos no padrão digitado, implicando que o usuário digitou mais do que um espaço em sequência.
        #"for letra in padrao" é um bloco que analisa por todas as letras digitadas no padrão, uma por uma.
        for letra in padrao:
            variavelControle += 1
            #Se há um dígito armazenado e o dígito atual não é um espaço vazio, o programa conclui que foi digitado um número maior que 9.
            if letraEncontrada == 1 and letra != ' ':
                print("Por favor, digite apenas números entre 1 e 9.")
                entradaErrada = 1
            else:
                letraEncontrada = 0
            if letra == '0':
                print("Por favor, digite apenas números entre 1 e 9.")
                entradaErrada = 1
            #Esse bloco é o que armazena que foi encontrada um dígito na entrada.
            if letra != ' ':
                letraEncontrada = 1
        if variavelControle != 7:
            print("Por favor, não adicione espaços desnecessários.")
            entradaErrada = 1
            
    #Esse bloco inicializa as variáveis que serão utilizadas no próximo bloco para analisar o padrão da cobra.
    #Partimos do princípio que um padrão com 2 cores iguais intermitentes (os padrões XAXB e AXAB) pertencem a cobras corais verdadeiras.
    #As variáveis  posicaoDaPrimeiraLetra e posicaoDaSegundaLetra guardam a posição das repetições, que é o que define se a cobra é verdadeira ou não.
    #A variável de controle controla se duas letras iguais foram encontradas no padrão e impede as comparações se isso for aconteceu.
    #O motivo de ela estar sendo inicializada aqui e zerada no próximo bloco é para caso o usuário queira analisar dois padrões, o resultado do padrão interior não interfira com a análise atual.
    posicaoDaPrimeiraLetra = 0
    posicaoDaSegundaLetra = 0
    variavelControle = 0
    
    #Para cada letra que há no padrão digitado... Note: o que é chamado aqui de letra são as cores/dígitos.
    for letra in padrao:
        #Se já foi encontrada a mesma letra em duas posições diferentes, esse If será falso, e o padrão não será comparado.
        if variavelControle < 2:
            variavelControle = 0
            posicaoDaLetra = 0
            primeiraChecagem = 1
            #Aqui, uma segunda estrutura é utilizada para comparar o padrão com ele mesmo, procurando repetições de dígitos que implicam na veracidade da cobra coral.
            for letra2 in padrao:
                #Se a letra não for um espaço vazio...
                if letra2 != ' ':
                    posicaoDaLetra += 1
                    #Se for encontrada uma letra igual a letra análisada no momento, a posição dela é marcada.
                    if letra == letra2:
                        #Esse if é para diferenciar se a mesma letra foi encontrada uma vez ou duas vezes.
                        #Se ela for encontrada duas vezes, a variável de controle será 2, e o programa irá parar de analisar o padrão.
                        if primeiraChecagem == 1:
                            posicaoDaPrimeiraLetra = posicaoDaLetra
                            variavelControle += 1
                            primeiraChecagem = 0
                        else:
                            posicaoDaSegundaLetra = posicaoDaLetra
                            variavelControle += 1
    
    #Baseado nos resultados obtidos na análise feita anteriormente, o programa diz se a cobra coral é verdadeira ou não.
    if (posicaoDaPrimeiraLetra == 1 and posicaoDaSegundaLetra == 3) or (posicaoDaPrimeiraLetra == 2 and posicaoDaSegundaLetra == 4):
        print("A cobra coral é verdadeira! Chame algum orgão capacitado para lidar com ela.\n")
    else:
        print("É uma cobra coral falsa. Chame algum orgão capacitado para lidar com ela.\n")
    
    #Aqui é perguntado ao usuário se ele quer fazer outra análise de padrão de cores de cobras corais.
    #Baseado na resposta do usuário, o código reinicia sua execução ou termina.
    entradaErrada = 1
    while entradaErrada == 1:
        desejaRepetir = input("Deseja testar um novo padrão de cores?\nCaso sim, digite '1'.\nCaso não, digite '2'.\n")
        entradaErrada = 0
        if desejaRepetir != '1' and desejaRepetir != '2':
            print("Por favor, digite apenas '1' ou '2'.")
            entradaErrada = 1
        if desejaRepetir == 2:
            novaEntrada = 0
    
    
    
    
    
    
    
    
    
    
    
    
    
    