#Além das saídas dos exemplos, foram testadas as seguintes saídas:
# 11, 25, 30 -> O carro precisa ser desacelerado
# 50, 100, 150 -> O carro deve manter sua velocidade.
# 60, 70, 300 -> O carro deve ser acelerado.
# 3, 302, 200 -> Retorna o erro onde os números não obedecem a regra A < B < C.
# 90, 102, 150 -> O carro deve ser acelerado.

#Os 5 prints a seguir explicam ao usuário o que o programa faz, seus critérios, os casos críticos de entrada, suas limitações, e suas saídas possíveis.
print("Esse programa dirá se um carro B deve ser acelerado, desacelerado ou mantido em velocidade constante, baseado na sua distância em relação à outros dois carros.")
print("O usuário dirá 3 números A, B e C, que são as posições dos carros A, B e C, respectivamente.")
print("Os números A, B e C devem ser a regra: 0 <= A < B < C <= 500. Ou seja: A é maior ou igual a 0 e menor que B. B é menor que C. C é menor ou igual a 500.")
print("O programa irá, então, retornar se o carro B precisa ser acelerado, se o carro B precisa ser desacelerado ou se o carro B precisa manter sua velocidade atual.")
print("Tenha em mente que o objetivo do carro B é ficar com a mesma distância em relação aos carros A e C.\n\n")

#Essa estrutura garante que as entradas estão dentro dos limites do código. A variável entradaErrada é a variável de controle do bloco While.
entradaErrada = 1
while entradaErrada == 1:
    posA = int(input("Digite a posição do carro A.\n"))
    posB = int(input("Digite a posição do carro B.\n"))
    posC = int(input("Digite a posição do carro C.\n"))
    entradaErrada = 0
    #Os blocos seguintes analisam os casos críticos do programa, imprimindo uma mensagem de erro equivalente à limitação não obedecida.
    #Esse bloco checa se alguma das posições é menor que 0, ativando a variável de controle no caso.
    if (posA < 0) or (posB < 0) or (posC < 0):
        print("ERRO NA ENTRADA\nNenhuma das posições pode ser menor que 0.")
        entradaErrada = 1
    #Esse bloco checa se as variáveis obedecem a regra A < B < C. Ativando a variável de controle caso não obedeçam.
    #O uso da palavra-chave "not" faz com que a estrutura condicional se torne: "Se (posB > posA e posC > posB) não for verdade"
    if not ((posB > posA) and (posC > posB)):
        print("ERRO NA ENTRADA\nOs números A, B e C devem obedecer a regra: A < B < C. Ou seja: A é menor que B, B é menor que C.")
        entradaErrada = 1
    #Esse bloco checa se alguma das posições é maior que 500, ativando a variável de controle no caso.
    if (posA > 500) or (posB > 500) or (posC > 500):
        print("ERRO NA ENTRADA\nA posição dos carros na rodovia não pode ser maior que 500.")
        entradaErrada = 1

#Esse bloco calcula a distância entre B e A e entre C e A.
distBA = posB - posA
distBC = posC - posB

#Esse bloco vê a relação entre as distâncias e dá a saída correta.
if distBC > distBA:
    print("O carro B precisa ser acelerado.")
elif distBC < distBA:
    print("O carro B precisa ser desacelerado.")
else:
    print("O carro B precisa manter sua velocidade atual.")